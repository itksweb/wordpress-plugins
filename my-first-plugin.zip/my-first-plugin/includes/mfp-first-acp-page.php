<div class="wrap">
  <h1>Hello!</h1>
  <p>This is my plugin's first page</p>
</div>